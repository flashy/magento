<?php

class Flashy_Integration_Model_Carthash extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('flashy/carthash');
    }
}