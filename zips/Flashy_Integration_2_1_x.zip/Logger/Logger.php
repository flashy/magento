<?php
namespace Flashy\Integration\Logger;

class Logger extends \Monolog\Logger
{
}
